#pragma once
#include <string>
using namespace std;
class Luna_Superior
{
	string nombre;
	int posicion;
	int vida;
	int ataque;
public:
	Luna_Superior();
	Luna_Superior(string nombre, int posicion, int vida, int ataque);
};

