#pragma once
#include "cazador.h"
class Pilar:protected cazador
{
	int lunasv;
public:
	Pilar(string name, int vida, int ataque, Katana color,Respiracion poder,int lunasv);//constructor
	Pilar();
};

