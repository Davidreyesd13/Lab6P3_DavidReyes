#pragma once
#include "Respiracion.h"
class Respiracion_Agua: protected Respiracion
{
	//metodo polimorfico
	virtual int poder() const;
	Respiracion_Agua();
};

