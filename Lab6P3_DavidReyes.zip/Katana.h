#pragma once
#include <string>
using namespace std;
class Katana
{
	int ataque;
	string colork;
public:
	Katana();
	Katana(int atac, string color);
};

