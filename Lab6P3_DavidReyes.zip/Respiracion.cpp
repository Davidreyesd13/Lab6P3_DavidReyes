#include "Respiracion.h"

int Respiracion::poder() const
{
	return 0;
}

Respiracion::Respiracion(string namerespi)//constructor
{
	this->namerespi = namerespi;
	
}
