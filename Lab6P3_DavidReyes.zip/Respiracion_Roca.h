#pragma once
#include "Respiracion.h"
class Respiracion_Roca:protected Respiracion {
	virtual int poder() const;
	Respiracion_Roca();
};

