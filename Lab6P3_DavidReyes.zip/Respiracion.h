#pragma once
#include <string>
#include<stdlib.h>
#include<ctime>
using namespace std;
class Respiracion
{
	string namerespi;
public:
	virtual int poder() const;
	Respiracion(string namerespi);
};

