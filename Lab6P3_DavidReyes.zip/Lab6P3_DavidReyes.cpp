#include <iostream>
#include <vector>
#include "cazador.h"
#include "Luna_Superior.h"
#include "Pilar.h"
#include "Respiracion.h";
#include "Respiracion_Agua.h";
#include "Respiracion_Fuego.h";
#include "Respiracion_Roca.h";
using namespace std;
int random(int limit ,int range) {//metodo random para crear la vida y el ataque;

	srand(time(NULL));
	int result = range + rand() % (limit + 1 - range);
	return result;
}
string colorkatana() {
	srand(time(NULL));
	string nk;//nombre katana
	int result = random(1,4);
	switch (result) {
	case 1:
		nk = "Rojo";
		break;
	case 2:
		nk = "negro";
		break;
	case 3:
		nk = "morado";
		break;
	case 4:
		nk = "naranja";
		break;
	}
	return nk;
}
void menu() {
	int pos;
	//Respiracion_Fuego rf();
	//Respiracion_Agua ra();
	string nombre;
	int respiracion;
	vector<cazador> cazadores;
	//cazadores.push_back(Pilar("Rengoku", random(20,30) + random(80,90), random(20, 30) + 100, Katana(random(10, 20), "Roja"), Respiracion("Fuego"), 1));//creacion de pilar
	vector<Luna_Superior> lunas;
	int respuesta = 1;
	while (respuesta != 7)
	{
		cout << "1.Crear Cazador\n2.Crear Pilar\n3.Crear Luna Superior\n4.Imprimir Cazadores y Pilares\n5.Imprimir Lunas superiores\n6.Simulacion\n7.Salir " << endl;
		cin >> respuesta;
		switch (respuesta) {
		case 1:
			cout << "Ingrese un nombre: ";
			cin >> nombre;
			cout << "Tipo de respiracion: \n1.Agua\n2.Fuego\n3.Roca\nElija una opcion: ";
			cin >> respiracion;
			switch (respiracion) {
			case 1:
				//ra;
				break;
			case 2:

				break;
			case 3:

				break;
			}
			break;
		case 2:
			cout << "Ingrese un nombre: ";
			cin >> nombre;
			cout << "Tipo de respiracion: \n1.Agua\n2.Fuego\n3.Roca\nElija una opcion: ";
			cin >> respiracion;
			switch (respiracion) {
			case 1:
				//ra;
				break;
			case 2:

				break;
			case 3:

				break;
			}
			break;
		case 3:
			cout << "Ingrese un nombre: ";
			cin >> nombre;
			cout << "Ingrese la posicion: ";
			cin >> pos;
			
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		default:
			cout << "Opcioncion no valida";
		}
	}
	cazadores.clear();
	lunas.clear();
}
int main()
{
	menu();

	return 0;
}