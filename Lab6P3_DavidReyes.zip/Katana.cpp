#include "Katana.h"

Katana::Katana()
{
}

Katana::Katana(int atac, string color)
{
	ataque = atac;
	colork = color;
}
