#pragma once
#include "Respiracion.h"
class Respiracion_Fuego: protected Respiracion
{
	//metodo polimorfico
	virtual int poder() const;
	Respiracion_Fuego();
};

