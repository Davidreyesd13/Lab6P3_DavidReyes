#include "cazador.h"

cazador::cazador(string name, int vida, int ataque, Katana color, Respiracion respi)
{
	this->name = name;
	this->vida = vida;
	this->color = color;
	
}

cazador::cazador()
{
}
